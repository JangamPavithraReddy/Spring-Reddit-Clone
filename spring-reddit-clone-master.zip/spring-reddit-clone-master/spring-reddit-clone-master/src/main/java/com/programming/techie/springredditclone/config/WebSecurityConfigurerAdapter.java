package com.programming.techie.springredditclone.config;

import org.springframework.context.annotation.Bean;
import org.springframework.security.config.BeanIds;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;

public abstract class WebSecurityConfigurerAdapter {
    @Bean(BeanIds.AUTHENTICATION_MANAGER)
    public abstract void configure(HttpSecurity httpSecurity) throws Exception;
}
